load("nicknameTags")
registerCoreModule("nicknameTags")