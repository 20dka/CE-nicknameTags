local M = {}

obj:queueGameEngineLua('if not nicknameTags then registerCoreModule("nicknameTags"); loadCoreExtensions() end')

return M