-- made by deer boi/tventy, relies on Cobalt Essentials by Preston

local M = {}



local function getTags(rawData)
	print("got: "..rawData)

	if rawData:sub(1,1) == ":" then rawData = rawData:sub(2) end -- cut off the leading :
	local nick = string.match(rawData,"^(.*);")
	local tag = string.gsub(rawData, nick..';', "")
	print(nick)
	print(tag)
	if tag == "" then return end
	tag = "["..tag.."]"
	MPVehicleGE.setPlayerNickPrefix(nick, tag)
	--MPVehicleGE.setPlayerNickPrefix(nick, "CEgroup", tag) --enable in the future (once beammp updates)
end

local function onExtensionLoaded()
	if MPGameNetwork then -- just so we dont instantly error out without BeamMP
		AddEventHandler("CEsendPlayerTags",	getTags)		
	end
end


M.onExtensionLoaded = onExtensionLoaded

return M